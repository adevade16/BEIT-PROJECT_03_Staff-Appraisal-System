# staff-appraisal-system
An online portal for college where institute can perform the appraisal and evaluation process.
